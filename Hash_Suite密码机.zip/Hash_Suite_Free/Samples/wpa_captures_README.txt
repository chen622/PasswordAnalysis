Sample files
============

wpa.cap:
    This is a sample file with a WPA handshake. The passphrase is 'biscotte'.

wpa2.eapol.cap: 
    This is a sample file with a WPA2 handshake. The passphrase is '12345678'.

wpa-psk-linksys.cap:
    This is a sample file with a WPA1 handshake along with some encrypted packets. The password is 'dictionary'.

wpa2-psk-linksys.cap:
    This is a sample file with a WPA2 handshake along with some encrypted packets. The password is 'dictionary'.
	
wpa-Induction.pcap:
	This is a sample file with a WPA2 handshake along with some encrypted packets. The password is 'Induction'.